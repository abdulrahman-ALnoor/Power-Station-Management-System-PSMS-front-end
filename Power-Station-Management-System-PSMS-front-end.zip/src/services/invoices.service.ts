import apiClient from './api'
import type { ApiResponse } from '@/types/api'

export interface ConsumptionChargeRecord {
  id: number
  customer: { id: number | null; full_name: string | null } | null
  meter: { id: number | null; meter_number: string | null } | null
  total_amount: number | string
  paid_amount: number | string
  remaining_amount: number | string
  status: string
}

export interface InvoiceApiRecord {
  id: number
  invoice_number: string
  customer: { id: number | null; name: string | null }
  consumption_charge: {
    id: number | null
    total_amount: number | null
    remaining_amount: number | null
  }
  paid_amount: number
  remaining_balance: number
  status: string
  payment_notes: string | null
  created_at: string
}

export interface CreateInvoicePayload {
  consumption_charge_id: number
  paid_amount: number
  payment_notes?: string
}

export interface InvoiceListResponse {
  data: InvoiceApiRecord[]
  current_page: number
  last_page: number
  total: number
}

export interface InvoiceStatsResponse {
  total_revenue: number
  total_invoices: number
  paid_invoices_count: number
  partially_paid_count: number
  overdue_amount: number
  this_month_collect: number
}

export async function fetchInvoices(params?: {
  page?: number
  per_page?: number
  search?: string
  status?: string
}): Promise<InvoiceListResponse> {
  const response = await apiClient.get<ApiResponse<unknown>>('/invoices', {
    params,
  })

  const raw = response.data.data as
    | InvoiceListResponse
    | InvoiceApiRecord[]
    | { data?: InvoiceApiRecord[]; current_page?: number; last_page?: number; total?: number }
    | undefined

  if (Array.isArray(raw)) {
    return {
      data: raw,
      current_page: 1,
      last_page: 1,
      total: raw.length,
    }
  }

  const paginated = raw ?? {}
  return {
    data: Array.isArray(paginated.data) ? paginated.data : [],
    current_page: paginated.current_page ?? 1,
    last_page: paginated.last_page ?? 1,
    total: paginated.total ?? (Array.isArray(paginated.data) ? paginated.data.length : 0),
  }
}

export async function fetchInvoiceStats(): Promise<InvoiceStatsResponse> {
  const response = await apiClient.get<ApiResponse<InvoiceStatsResponse>>('/invoices/stats')
  return response.data.data
}

export async function fetchConsumptionCharges(): Promise<ConsumptionChargeRecord[]> {
  const response = await apiClient.get<ApiResponse<ConsumptionChargeRecord[]>>(
    '/consumption-charges',
  )
  return response.data.data
}

export async function createInvoice(
  payload: CreateInvoicePayload,
): Promise<InvoiceApiRecord> {
  const response = await apiClient.post<ApiResponse<InvoiceApiRecord>>(
    '/invoices',
    payload,
  )
  return response.data.data
}

export interface UpdateInvoicePayload {
  outstanding_before_payment?: number
  paid_amount?: number
  remaining_balance?: number
  status?: 'paid' | 'partially_paid'
  payment_notes?: string
}

export async function updateInvoice(
  id: number,
  payload: UpdateInvoicePayload,
): Promise<InvoiceApiRecord> {
  const response = await apiClient.put<ApiResponse<InvoiceApiRecord>>(
    `/invoices/${id}`,
    payload,
  )
  return response.data.data
}

export async function deleteInvoice(id: number): Promise<void> {
  await apiClient.delete(`/invoices/${id}`)
}

export async function downloadInvoicePdf(
  invoiceId: number,
): Promise<Blob> {
  const response = await apiClient.get(
    `/invoices/${invoiceId}/pdf`,
    {
      responseType: 'blob',
    },
  )

  return response.data
}
export interface MonthlyRevenueItem {
  month: number
  invoices_amount: number | string
  collections_amount: number | string
}

export async function fetchMonthlyRevenue(): Promise<
  MonthlyRevenueItem[]
> {
  const response = await apiClient.get(
    '/invoices/monthly-revenue',
  )

  return response.data.data
}

export interface StatusDistributionItem {
  name: string
  value: number | string
}

export async function fetchStatusDistribution(): Promise<
  StatusDistributionItem[]
> {
  const response = await apiClient.get(
    '/invoices/status-distribution',
  )

  return response.data.data
}


export interface RevenueReport {
  total_invoices: number
  total_collected: number
  total_remaining: number
  total_invoices_count: number
}

export async function fetchRevenueReport(): Promise<
  RevenueReport
> {
  const response = await apiClient.get(
    '/reports/revenue',
  )

  return response.data.data
}