import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import {
  ArrowRight,
  FileText,
  Wallet,
  CircleDollarSign,
  ReceiptText,
  Loader2,
} from 'lucide-react'

import { useNavigate } from 'react-router-dom'

import {
  fetchRevenueReport,
  type RevenueReport,
} from '@/services/invoices.service'

import { formatCurrency } from '@/utils/currency'
import { useLanguage } from '@/hooks/useLanguage'

export function RevenueReportPage() {
  const { t } = useTranslation()
  const { isRTL } = useLanguage()
  const navigate = useNavigate()

  const [report, setReport] =
    useState<RevenueReport | null>(null)

  const [isLoading, setIsLoading] =
    useState(true)

  useEffect(() => {
    const loadReport = async () => {
      try {
        const data =
          await fetchRevenueReport()

        setReport(data)
      } catch (error) {
        console.error(
          'Failed to load revenue report:',
          error,
        )
      } finally {
        setIsLoading(false)
      }
    }

    void loadReport()
  }, [])

  if (isLoading) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <Loader2
          className="animate-spin text-primary"
          size={36}
        />
      </div>
    )
  }

  return (
    <div className="space-y-6">

      {/* رأس الصفحة */}
      <div className="flex items-center justify-between">

        <div>
          <h1 className="text-2xl font-bold text-on-surface dark:text-on-dark">
            تقرير الإيرادات
          </h1>

          <p className="text-on-surface-variant mt-2">
            نظرة شاملة على الإيرادات والتحصيلات
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl border border-outline-variant hover:bg-surface-container transition-colors"
        >
          <ArrowRight size={20} />

          <span>
            رجوع
          </span>
        </button>

      </div>

      {/* بطاقات الإحصائيات */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">

        {/* إجمالي الفواتير */}
        <ReportCard
          title="إجمالي الفواتير"
          value={
            formatCurrency(
              Number(
                report?.total_invoices ?? 0,
              ),
              isRTL,
            )
          }
          icon={
            <FileText size={26} />
          }
        />

        {/* إجمالي التحصيل */}
        <ReportCard
          title="إجمالي التحصيلات"
          value={
            formatCurrency(
              Number(
                report?.total_collected ?? 0,
              ),
              isRTL,
            )
          }
          icon={
            <Wallet size={26} />
          }
        />

        {/* المبلغ المتبقي */}
        <ReportCard
          title="إجمالي المتبقي"
          value={
            formatCurrency(
              Number(
                report?.total_remaining ?? 0,
              ),
              isRTL,
            )
          }
          icon={
            <CircleDollarSign size={26} />
          }
        />

        {/* عدد الفواتير */}
        <ReportCard
          title="عدد الفواتير"
          value={
            String(
              report?.total_invoices_count ?? 0,
            )
          }
          icon={
            <ReceiptText size={26} />
          }
        />

      </div>

    </div>
  )
}

interface ReportCardProps {
  title: string
  value: string
  icon: React.ReactNode
}

function ReportCard({
  title,
  value,
  icon,
}: ReportCardProps) {
  return (
    <div className="bg-surface-white dark:bg-surface-container-low rounded-2xl p-6 shadow-[0px_4px_12px_rgba(0,0,0,0.05)]">

      <div className="flex items-center justify-between mb-5">

        <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
          {icon}
        </div>

      </div>

      <p className="text-sm text-on-surface-variant mb-2">
        {title}
      </p>

      <h2 className="text-2xl font-bold text-on-surface dark:text-on-dark">
        {value}
      </h2>

    </div>
  )
}